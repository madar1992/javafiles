package com.OneToMany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MapDemo {
   public static void main(String[] args) {
	
	Configuration cfg=new Configuration();
	cfg.configure("com/bitlabs/HibernateProject/hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	//creating question
	Question1 q1=new Question1();
	q1.setQuestionId(1212);
	q1.setQuestion("What is java");
	
	//creating an answerss class object
	Answer1 ans=new Answer1();
	ans.setAnswerId(343);
	ans.setAnswer("java is programming language");
	ans.setQuestion(q1);
	
	Answer1 ans1=new Answer1();
	ans1.setAnswerId(33);
	ans1.setAnswer("with the help of java we can create software");
	ans1.setQuestion(q1);
	
	Answer1 ans2=new Answer1();
	ans2.setAnswerId(370);
	ans2.setAnswer("java has different types of frame wors");
	ans2.setQuestion(q1);
    
	List<Answer1> list=new ArrayList<Answer1>();
	list.add(ans);
	list.add(ans1);
	list.add(ans2);
	
	q1.setAnswers(list);
	
	
	//session
	Session s=factory.openSession();
	Transaction tx=s.beginTransaction();
	s.save(q1);
	s.save(ans);
	s.save(ans1);
	s.save(ans2);
	tx.commit();
	
	//fetching................
	Question1 newQ=(Question1)s.get(Question1.class, 1212);
	System.out.println(newQ.getQuestion());
	List<Answer1> list1=newQ.getAnswers();
	for(Answer1 a: list1) {
		System.out.println(a.getAnswer());
	}
	factory.close();   
}
}
