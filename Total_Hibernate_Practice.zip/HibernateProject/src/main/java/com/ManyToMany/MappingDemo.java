package com.ManyToMany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MappingDemo {

	
	public static void main(String [] args) {
		Configuration cfg=new Configuration();
		cfg.configure("com/bitlabs/HibernateProject/hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Emp e1=new Emp();
		Emp e2=new Emp();
		e1.setEid(34);
		e1.setEname("madar");
		
		e2.setEid(35);
		e2.setEname("dudekula");
		
		Project p1=new Project();
		Project p2=new Project();
		
		p1.setPid(1212);
		p1.setProject_name("Liberay management system");
		
		p2.setPid(1213);
	    p2.setProject_name("chatbot");
	    
	    List<Project> projects=new ArrayList<Project>();
	    List<Emp> employees=new ArrayList<Emp>();
	    
	    projects.add(p1);
	    projects.add(p2);
	    employees.add(e1);
	    employees.add(e2);
	    
	    p2.setEmployees(employees);
	    e1.setProjects(projects);
	    
	    Session s=factory.openSession();
	    Transaction tx=s.beginTransaction();
	    s.save(p1);
	    s.save(p2);
	    s.save(e1);
	    s.save(e2);
	    
	    tx.commit();
		
		factory.close();
	}
}
