package com.ManyToMany;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Project {
     @Id
	private int pid;
	private String project_name;
	@ManyToMany
	private List<Emp> employees;
	
	
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Project(int pid, String project_name, List<Emp> employees) {
		super();
		this.pid = pid;
		this.project_name = project_name;
		this.employees = employees;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	public List<Emp> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Emp> employees) {
		this.employees = employees;
	}
	
}
