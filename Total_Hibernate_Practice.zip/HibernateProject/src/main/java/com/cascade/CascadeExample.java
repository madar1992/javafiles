package com.cascade;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.OneToMany.Answer1;
import com.OneToMany.Question1;

public class CascadeExample {
 public static void main(String[] args) {
	SessionFactory factory=new Configuration().configure("com/bitlabs/HibernateProject/Hibernate.cfg.xml").buildSessionFactory();
	Session session=factory.openSession();
	
   	Question1 q1=new Question1();
   	q1.setQuestionId(1444);
   	q1.setQuestion("ARE YOU READY TO LEARN SPRING?");
   	
   	Answer1 a1=new Answer1();
   	a1.setAnswerId(200);
   	a1.setAnswer("Yes, I am ready ");
   	
   	Answer1 a2=new Answer1();
   	a2.setAnswerId(210);
   	a2.setAnswer("I hope i am going to love it");
   	
   	Answer1 a3=new Answer1();
   	a3.setAnswerId(220);
   	a3.setAnswer("I never thought i would come this far");
   
   	List<Answer1> list=new ArrayList<Answer1>();
   	list.add(a1);
   	list.add(a2);
   	list.add(a3);
   	
   	q1.setAnswers(list);
	Transaction tx=session.beginTransaction();
	session.save(q1); //If i use cascade in question1 class at mapping tag i don't have to save the answers separately
	
	/*session.save(a1);  
	session.save(a2);
	session.save(a3);*/
	
	
	tx.commit();
	session.close();
	factory.close();
 
 }
}
