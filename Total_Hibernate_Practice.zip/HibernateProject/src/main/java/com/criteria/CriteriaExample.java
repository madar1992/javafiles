package com.criteria;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.bitlabs.HibernateProject.Student;

public class CriteriaExample {
public static void main(String[] args) {
	
	SessionFactory factory=new Configuration().configure("com/bitlabs/HibernateProject/Hibernate.cfg.xml").buildSessionFactory();
    Session session=factory.openSession();
    //Here you don't need any query in criteria API
    /*
    Criteria c=session.createCriteria(Student.class);
    
    List<Student> list=c.list();
    
    for(Student s: list) {
    	System.out.println(s);
    }
*/
    //With restriction
 Criteria c=session.createCriteria(Student.class);
 
    c.add(Restrictions.gt("id",24)); //gt means greater than like this a lot of methods are there
    
    List<Student> list=c.list();
    
    for(Student s: list) {
    	System.out.println(s);
    }
   session.close();



}
}
