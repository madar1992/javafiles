package com.states;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class StateDemo {
	
	public static void main(String [] args) {
		//practical of hibernate object states
		//Transient
		//Persistent
		//Detached
		//Removed
		//Configuration cfg=new Configuration();
		//cfg.configure();
		//SessionFactory factory=cfg.buildSessionFactory();
		System.out.println("i am working");
		SessionFactory factory=new Configuration().configure("com/bitlabs/HibernateProject/hibernate.cfg.xml").buildSessionFactory();
		
		//Creating student object
		StudentState student=new StudentState();
		student.setId(101);
		student.setName("madar saheb");
		student.setCity("Kurnool");
		//student object is now in Transient state
		
		
		Session s=factory.openSession();
		Transaction tx=s.beginTransaction();
		s.save(student);
		//student object is now in persistent state
		
		student.setName("Jhon");
		//student object is now in persistent state
		//The above change is also reflected in database too
		tx.commit();
		
		
		s.close();  //or s.clear();
		//student object is now in detached state
		student.setName("jakkir");
		//The above change is not reflected in database
		System.out.println(student.getName());
		
		
		
		factory.close();
		
	}

}
