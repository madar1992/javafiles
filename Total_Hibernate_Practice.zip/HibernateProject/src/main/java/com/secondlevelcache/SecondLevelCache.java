package com.secondlevelcache;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cache.ehcache.internal.EhcacheRegionFactory;
import org.hibernate.cfg.Configuration;

import com.bitlabs.HibernateProject.Student;
public class SecondLevelCache {
 public static void main(String[] args) {
	 SessionFactory factory=new Configuration().configure("com/bitlabs/HibernateProject/Hibernate.cfg.xml").buildSessionFactory();
	    Session session=factory.openSession();	
	
	    Student student=session.get(Student.class, 124);
	    System.out.println(student);
	    session.close();
	    
	    
	    Session session1=factory.openSession();	
		
	    Student student1=session1.get(Student.class, 124);
	    System.out.println(student1);
	    session1.close();
	    
	    
	     
	    
}
}
