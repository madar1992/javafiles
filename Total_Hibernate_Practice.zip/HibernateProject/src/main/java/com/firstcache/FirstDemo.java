package com.firstcache;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.bitlabs.HibernateProject.Student;

public class FirstDemo {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration().configure("com/bitlabs/HibernateProject/Hibernate.cfg.xml").buildSessionFactory();
	    Session session=factory.openSession();	
	
	    Student student=session.get(Student.class, 124);
	    System.out.println(student);
	    
	    System.out.println("Working on the above obj to get again and sql quiry is not fired 2 nd time for the same object");
	    
	    Student student1=session.get(Student.class, 124);
	    System.out.println(student1);
	    
	    System.out.println("Before closing session  " +session.contains(student1));
	    
	    session.close(); 
	    factory.close();
	}
	
}
