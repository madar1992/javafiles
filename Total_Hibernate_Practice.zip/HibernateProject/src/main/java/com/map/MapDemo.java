package com.map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MapDemo {
   public static void main(String[] args) {
	
	Configuration cfg=new Configuration();
	cfg.configure("com/bitlabs/HibernateProject/hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	//creating question
	Question q1=new Question();
	q1.setQuestionId(1212);
	q1.setQuestion("What is java");
	
	//creating an answerss class object
	Answer ans=new Answer();
	ans.setAnswerId(343);
	ans.setAnswer("java is programming language");
	q1.setAnswer(ans);
    ans.setQuestion(q1);
    
	
	Question q2=new Question();
	q2.setQuestionId(242);
	q2.setQuestion("What is collection framework");
	
	//creating an answerss class object
	Answer ans2=new Answer();
	ans2.setAnswerId(344);
	ans2.setAnswer("API to work with group of objects in java");
	
	q1.setAnswer(ans2);
	ans2.setQuestion(q2);
	//session
	Session s=factory.openSession();
	Transaction tx=s.beginTransaction();
	
	s.save(q1);
	s.save(q2);
	s.save(ans);
	s.save(ans2);
	tx.commit();
	
	//fetching................
	Question newQ=(Question)s.get(Question.class, 1212);
	System.out.println(newQ.getQuestion());
	System.out.println(newQ.getAnswer().getAnswer());
	factory.close();   
}
}
