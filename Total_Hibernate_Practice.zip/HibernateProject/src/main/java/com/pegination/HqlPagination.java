package com.pegination;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.bitlabs.HibernateProject.Student;

public class HqlPagination {
 public static void main(String[] args) {
	
	 SessionFactory factory=new Configuration().configure("com/bitlabs/HibernateProject/hibernate.cfg.xml").buildSessionFactory();
	 Session session=factory.openSession();
	 
	 Query<Student> q=session.createQuery("from Student",Student.class);
	 //Query q=session.createQuery("from Student");
	 //implementing pegination using  hiberbnate
	 
	 //Start from in a page
	 q.setFirstResult(0);
	 
	 //Ends in a page
	 q.setMaxResults(1);
	 
	 List<Student> list5=q.list();
	 for(Student student: list5) {
		 System.out.println(student);
	 }
	 
	 factory.close();
}
}
