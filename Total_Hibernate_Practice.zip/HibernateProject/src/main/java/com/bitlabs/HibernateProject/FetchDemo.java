package com.bitlabs.HibernateProject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FetchDemo {
  public static void main(String[] args) {
	  Configuration cfg=new Configuration();
      cfg.configure("com/bitlabs/HibernateProject/hibernate.cfg.xml");
      SessionFactory factory=cfg.buildSessionFactory();
      
      Session session=factory.openSession();
       
      //get student of id 101
      Student student=session.get(Student.class, 101);
      System.out.println(student);
    //load student of id 101
      Student student1=session.get(Student.class, 101);
      System.out.println(student1);
      
      
      
      session.close();
      factory.close();
      
	  
	  
}
}
