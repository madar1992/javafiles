package com.hql;

import java.util.Arrays;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.bitlabs.HibernateProject.Student;

public class HQLExample {
  public static void main(String[] args) {
	SessionFactory factory=new Configuration().configure("com/bitlabs/HibernateProject/hibernate.cfg.xml").buildSessionFactory();
	Session s=factory.openSession();
	/*
	  String query="from Student where city='kurnool'";
	
	Query q=s.createQuery(query);
	
	//Single result -(unique)
	//Multiple result -(list)
	List<Student> list=q.list();
	
	for(Student a: list) {
		System.out.println(a.getName()+"    "+a.getSid()+"   "+a.getCity()+"  "+a.getCerti());
  }
  */
	 String query="from Student as st where st.city= :x and st.name= :n";
		
		Query q=s.createQuery(query);
		q.setParameter("x","kurnool");
		q.setParameter("n", "saheb");
		
		//Single result -(unique)
		//Multiple result -(list) 
		List<Student> list=q.list();
		
		for(Student a: list) {
			System.out.println(a.getName()+"    "+a.getSid()+"   "+a.getCity()+"  "+a.getCerti());
	  }
		Transaction tx=s.beginTransaction();
		/*System.out.println("Delte query-------------------");
		Query q2=s.createQuery("delete from Student as st where st.city=:c");
		q2.setParameter("c", "kurnool");
		
		int r=q2.executeUpdate();
		tx.commit();
		System.out.println("Deleted : ");
		System.out.println(r);*/
		
		/*
		 System.out.println("Update query-------------------");
		 
		Query q3=s.createQuery("update Student set city=:c where name=:n");
		q3.setParameter("c", "kurnool");
		q3.setParameter("n", "alli saheb");
		int r=q3.executeUpdate();
		tx.commit();
		System.out.println("Updated : ");
		System.out.println(r);
		
		*/
		
		//How to execute join query
		Query q4=s.createQuery("select q.question , q.questionId ,a.answer from Question1 as q INNER JOIN q.answers as a ");
		
		List<Object[] > list3=q4.getResultList(); //q4.list(); can be used
		
		
		for(Object[] arr:list3) {
			System.out.println(Arrays.toString(arr));
		}
		
	factory.close();
}
}
